<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateStockbrokersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('stockbrokers', function (Blueprint $table) {
            $table->increments('id');
            $table->string('brokerName', 100);
            $table->string('createdBy', 100);
            $table->enum('isActive', ['Y', 'N'])->default('Y');
            $table->enum('isDelete', ['Y', 'N'])->default('Y');
            $table->enum('isApproved', ['Y', 'N'])->default('Y');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('stockbrokers');
    }
}
