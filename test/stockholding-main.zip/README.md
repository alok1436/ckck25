1. you have to install composer.

2. composer update

3. php artisan migrate

4. php artisan db:seed

5. php artisan serve --port=8080
