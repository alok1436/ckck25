<!-- App favicon -->
<link rel="shortcut icon" href="<?php echo e(asset('assets/images/favicon.ico')); ?>">
<?php echo $__env->yieldContent('css'); ?>
<!-- Bootstrap Css -->
<link href="<?php echo e(asset('assets/css/bootstrap.min.css')); ?>" id="bootstrap-style" rel="stylesheet" type="text/css" />
<!-- Icons Css -->
<link href="<?php echo e(asset('assets/css/icons.min.css')); ?>" rel="stylesheet" type="text/css" />
<!-- App Css-->
<link href="<?php echo e(asset('assets/css/app.min.css')); ?>" id="app-style" rel="stylesheet" type="text/css" />
<link href="<?php echo e(asset('assets/css/validations.css')); ?>" id="app-style" rel="stylesheet" type="text/css" />
<link href="<?php echo e(asset('assets/css/custom.css')); ?>" id="app-style" rel="stylesheet" type="text/css" />
<link href="<?php echo e(asset('assets/libs/bootstrap-datepicker/css/bootstrap-datepicker.min.css')); ?>" rel="stylesheet">
<link rel="stylesheet" href="<?php echo e(asset('assets/dropify/dist/css/dropify.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('assets/daterangepicker/daterangepicker.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('assets/timepicker/bootstrap-timepicker.min.css')); ?>">
<!-- Sweet Alert-->
<link href="<?php echo e(asset('assets/libs/sweetalert2/sweetalert2.min.css')); ?>" rel="stylesheet" type="text/css" /><?php /**PATH C:\Users\PC\Downloads\stockholding-main (1)\stockholding-main\resources\views/admin/layouts/partials/appcss.blade.php ENDPATH**/ ?>