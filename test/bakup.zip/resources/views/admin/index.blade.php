@extends('admin.layouts.app')
@section('title', 'Dashboard')
@section('content')


@yield('content')
@endsection