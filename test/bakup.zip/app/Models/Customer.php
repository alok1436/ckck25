<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Customer extends Model
{
    protected $fillable = [
        'name','email', 'age', 'date', 'address', 'gender' ,'city_id', 'number', 'customerGroupID', 'stockBroker', 'AccountNumber', 'routesOfKnownID', 'createdBy','updatedBy', 'isApproved','created_at', 'updated_at', 'isActive', 'isDelete'
    ];
}
