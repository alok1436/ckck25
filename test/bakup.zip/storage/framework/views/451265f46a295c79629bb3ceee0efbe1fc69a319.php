<!doctype html>
<html lang="en">
    <head>

        <meta charset="utf-8" />
        <title><?php echo $__env->yieldContent('title'); ?> | 7Stock Holding </title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta content="Premium Multipurpose Admin & Dashboard Template" name="description" />
        <meta content="Themesbrand" name="author" />
        <!-- App favicon -->
        <link rel="shortcut icon" href="<?php echo e(url('assets/images/favicon.ico')); ?>"> 
        <?php echo $__env->make('admin.layouts.partials.auth-css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        
        
    </head>

<body>
    <?php echo $__env->yieldContent('content'); ?>
    <?php echo $__env->make('admin.layouts.partials.auth-javascript', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>

</html><?php /**PATH /home/ckck25com/public_html/resources/views/admin/layouts/auth.blade.php ENDPATH**/ ?>