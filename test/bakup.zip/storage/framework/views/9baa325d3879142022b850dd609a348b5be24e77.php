<footer class="footer">
    <div class="container-fluid">
        <div class="row">
            <div class="col-sm-12">
                © <script>document.write(new Date().getFullYear())</script> 7Stock <span class="d-none d-sm-inline-block"> - Crafted with <i class="mdi mdi-heart text-danger"></i> by 7Stcok Holding Team.</span>
            </div>
        </div>
    </div>
</footer><?php /**PATH /home/ckck25com/public_html/resources/views/admin/layouts/partials/footer.blade.php ENDPATH**/ ?>